/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trifichierperso;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author steem
 */
public class Fenetre extends JFrame {

    private Panneau p = new Panneau();

    public Fenetre() {
        initFen();
    }

    private void initFen() {
        //--Proprieter du Jframe
        ImageIcon img = new ImageIcon(getClass().getResource("/icon/icon.png"));
        this.setIconImage(img.getImage());
        this.setContentPane(p);
        this.setTitle("Trifichier");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setBounds(200, 200, 500, 400);
        this.setVisible(true);
        //enpeche la fenetre de s'agrandire
        this.setResizable(false);
    }

    public void changepan(JPanel Panneau) {
        //methode pour changer de Jpanel utiliser par le Jframe
        this.getContentPane().removeAll();
        this.setContentPane(Panneau);
        revalidate(); 
        repaint();

    }
}
