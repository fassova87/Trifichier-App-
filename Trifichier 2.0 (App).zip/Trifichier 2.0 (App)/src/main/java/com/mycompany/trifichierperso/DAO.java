/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trifichierperso;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author steem
 */
public abstract class DAO <T,K> {
    public Connection conn = DAOFactory.getConnection();
    
    public abstract T create(T obj) throws SQLException ;
    public abstract T findById(K id) throws SQLException;
    public abstract T findByDestination(K id) throws SQLException;
    public abstract T[] findAll() throws SQLException;
    public abstract T update(T obj,String fileName) throws SQLException;
    public abstract K delete(T obj) throws SQLException;
    public abstract K deleteById(K id) throws SQLException;
    public abstract T rsToObj(ResultSet rs) throws SQLException;
    public abstract ResultSet findallRs()throws SQLException;
}
