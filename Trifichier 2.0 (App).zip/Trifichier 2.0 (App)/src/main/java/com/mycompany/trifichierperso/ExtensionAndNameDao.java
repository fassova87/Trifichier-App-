package com.mycompany.trifichierperso;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ExtensionAndNameDao extends DAO<ExtensionAndName, String> {

    @Override
    public ExtensionAndName create(ExtensionAndName obj) throws SQLException {
        try (Connection conn = DAOFactory.getConnection()) {
            String req = "INSERT INTO triinfo (extension, DossierDestination) VALUES (?, ?);";
            PreparedStatement ps = conn.prepareStatement(req);
            ps.setString(1, obj.getExtension());
            ps.setString(2, obj.getFileName());
            ps.executeUpdate();
            ps.close(); // Assurez-vous de fermer le PreparedStatement
            return findById(obj.getExtension());
        }
    }

    @Override
    public ExtensionAndName findById(String id) throws SQLException {
        try (Connection conn = DAOFactory.getConnection()) {
            String req = "SELECT * FROM triinfo WHERE extension = ?;";
            PreparedStatement ps = conn.prepareStatement(req);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                rs.close();
                ps.close();
                return new ExtensionAndName();
            } else {
                ExtensionAndName result = rsToObj(rs);
                rs.close();
                ps.close();
                return result;
            }
        }
    }

    @Override
    public ExtensionAndName[] findAll() throws SQLException {
        try (Connection conn = DAOFactory.getConnection()) {
            String req = "SELECT * FROM triinfo;";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(req);
            ArrayList<ExtensionAndName> liste = new ArrayList<>();
            while (rs.next()) {
                liste.add(rsToObj(rs));
            }
            rs.close();
            st.close();
            return liste.toArray(new ExtensionAndName[liste.size()]);
        }
    }

    public ExtensionAndName update(ExtensionAndName obj, String fileName) throws SQLException {
        try (Connection conn = DAOFactory.getConnection()) {
            String req = "UPDATE triinfo SET DossierDestination = ? WHERE extension = ?;";
            PreparedStatement ps = conn.prepareStatement(req);
            ps.setString(1, fileName);
            ps.setString(2, obj.getExtension());
            ps.executeUpdate();
            ps.close();
            return findById(obj.getExtension());
        }
    }

    @Override
    public String delete(ExtensionAndName obj) throws SQLException {
        try (Connection conn = DAOFactory.getConnection()) {
            String req = "DELETE FROM triinfo WHERE extension = ?;";
            PreparedStatement ps = conn.prepareStatement(req);
            ps.setString(1, obj.getExtension());
            int rowAffected = ps.executeUpdate();
            ps.close();
            return rowAffected > 0 ? "Ok" : "No rows affected";
        }
    }

    @Override
    public String deleteById(String id) throws SQLException {
        try (Connection conn = DAOFactory.getConnection()) {
            String req = "DELETE FROM triinfo WHERE extension = ?;";
            PreparedStatement ps = conn.prepareStatement(req);
            ps.setString(1, id);
            int rowAffected = ps.executeUpdate();
            ps.close();
            return rowAffected > 0 ? "Ok" : "No rows affected";
        }
    }

    @Override
    public ExtensionAndName rsToObj(ResultSet rs) throws SQLException {
        ExtensionAndName EAN = new ExtensionAndName();
        EAN.setExtension(rs.getString(1));
        EAN.setFileName(rs.getString(2));
        return EAN;
    }

    
@Override
public ResultSet findallRs() throws SQLException {
    Connection conn = DAOFactory.getConnection();
    String req = "SELECT * FROM triinfo;";
    Statement st = conn.createStatement();
    return st.executeQuery(req);
}
    @Override
    public ExtensionAndName findByDestination(String id) throws SQLException {
        try (Connection conn = DAOFactory.getConnection()) {
            String req = "SELECT * FROM triinfo WHERE DossierDestination = ?;";
            PreparedStatement ps = conn.prepareStatement(req);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                rs.close();
                ps.close();
                return new ExtensionAndName();
            } else {
                ExtensionAndName result = rsToObj(rs);
                rs.close();
                ps.close();
                return result;
            }
        }
    }
}
