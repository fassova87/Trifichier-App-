/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trifichierperso;

/**
 *
 * @author steem
 */
public class SourceAndDestinationFolder {
      private String SourceFolder;
      private String DestinationFolder;
      private String Dossier;
      private String Fichier;
//--Constructor---------------------------------------------------------------------------------------------------------------------------------------
    public SourceAndDestinationFolder(String SourceFolder, String DestinationFolder,String Dossier,String Fichier) {
        this.SourceFolder = SourceFolder;
        this.DestinationFolder = DestinationFolder;
        this.Dossier=Dossier;
        this.Fichier=Fichier;
    }

    public SourceAndDestinationFolder() {

    }
    
    public String getDossier() {
        return Dossier;
    }

    public void setDossier(String Dossier) {
        this.Dossier = Dossier;
    }

    public String getFichier() {
        return Fichier;
    }

//--Geter and Seter---------------------------------------------------------------------------------------------------------------------------------------
    public void setFichier(String Fichier) {    
        this.Fichier = Fichier;
    }

    public String getSourceFolder() {
        return SourceFolder;
    }

    public void setSourceFolder(String SourceFolder) {
        this.SourceFolder = SourceFolder;
    }

    public String getDestinationFolder() {
        return DestinationFolder;
    }

    public void setDestinationFolder(String DestinationFolder) {
        this.DestinationFolder = DestinationFolder;
    }

    @Override
    public String toString() {
        return "SourceAndDestinationFolder{" + "SourceFolder=" + SourceFolder + ", DestinationFolder=" + DestinationFolder + ", Dossier=" + Dossier + ", Fichier=" + Fichier + '}';
    }

   
    
  
   
    
}
