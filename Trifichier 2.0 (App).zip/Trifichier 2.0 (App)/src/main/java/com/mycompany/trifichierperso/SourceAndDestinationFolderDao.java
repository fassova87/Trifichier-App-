package com.mycompany.trifichierperso;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class SourceAndDestinationFolderDao extends DAO<SourceAndDestinationFolder, String>{

    private Connection conn;

    // Constructeur avec connexion
    public SourceAndDestinationFolderDao(Connection conn) {
        this.conn = conn;
    }

    // Supprimez le constructeur par défaut s'il n'est pas nécessaire
    // public SourceAndDestinationFolderDao() {
    //    throw new UnsupportedOperationException("Not supported yet."); 
    // }

    @Override
    public SourceAndDestinationFolder create(SourceAndDestinationFolder obj) throws SQLException {
        String req = "INSERT INTO sourceanddestinationfolder (SourceFolder, Destination, Fichier, Dossier) VALUES (?, ?, ?, ?);";
        try (PreparedStatement ps = conn.prepareStatement(req)) {
            ps.setString(1, obj.getSourceFolder());
            ps.setString(2, obj.getDestinationFolder());
            ps.setString(3, obj.getFichier());
            ps.setString(4, obj.getDossier());
            ps.executeUpdate();
        }
        return findById(obj.getSourceFolder());
    }

    @Override
    public SourceAndDestinationFolder findById(String sourceFolder) throws SQLException {
        String req = "SELECT * FROM sourceanddestinationfolder WHERE SourceFolder = ?;";
        try (PreparedStatement ps = conn.prepareStatement(req)) {
            ps.setString(1, sourceFolder);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rsToObj(rs);
                } else {
                    return null;
                }
            }
        }
    }

    @Override
    public SourceAndDestinationFolder[] findAll() throws SQLException {
        String req = "SELECT * FROM sourceanddestinationfolder;";
        ArrayList<SourceAndDestinationFolder> liste = new ArrayList<>();
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(req)) {
            while (rs.next()) {
                liste.add(rsToObj(rs));
            }
        }
        return liste.toArray(new SourceAndDestinationFolder[liste.size()]);
    }

    public SourceAndDestinationFolder update(SourceAndDestinationFolder obj, String DestinationFolder, String Fichier, String Dossier) throws SQLException {
        String req = "UPDATE sourceanddestinationfolder SET Destination = ?, Fichier = ?, Dossier = ? WHERE SourceFolder = ?;";
        try (PreparedStatement ps = conn.prepareStatement(req)) {
            ps.setString(1, DestinationFolder);
            ps.setString(2, Fichier);
            ps.setString(3, Dossier);
            ps.setString(4, obj.getSourceFolder());
            ps.executeUpdate();
        }
        return findById(obj.getSourceFolder());
    }

    @Override
    public String delete(SourceAndDestinationFolder obj) throws SQLException {
        String req = "DELETE FROM sourceanddestinationfolder WHERE SourceFolder = ?;";
        try (PreparedStatement ps = conn.prepareStatement(req)) {
            ps.setString(1, obj.getSourceFolder());
            int rowAffected = ps.executeUpdate();
            return rowAffected > 0 ? "Ok" : "No rows affected";
        }
    }

    @Override
    public String deleteById(String sourceFolder) throws SQLException {
        String req = "DELETE FROM sourceanddestinationfolder WHERE SourceFolder = ?;";
        try (PreparedStatement ps = conn.prepareStatement(req)) {
            ps.setString(1, sourceFolder);
            int rowAffected = ps.executeUpdate();
            return rowAffected > 0 ? "Ok" : "No rows affected";
        }
    }

    @Override
    public SourceAndDestinationFolder rsToObj(ResultSet rs) throws SQLException {
        SourceAndDestinationFolder obj = new SourceAndDestinationFolder();
        obj.setSourceFolder(rs.getString("SourceFolder"));
        obj.setDestinationFolder(rs.getString("Destination"));
        obj.setFichier(rs.getString("Fichier"));
        obj.setDossier(rs.getString("Dossier"));
        return obj;
    }

    @Override
    public ResultSet findallRs() throws SQLException {
        String req = "SELECT * FROM sourceanddestinationfolder;";
        Statement st = conn.createStatement();
        return st.executeQuery(req);
    }

    @Override
    public SourceAndDestinationFolder findByDestination(String destinationFolder) throws SQLException {
        String req = "SELECT * FROM sourceanddestinationfolder WHERE Destination = ?;";
        try (PreparedStatement ps = conn.prepareStatement(req)) {
            ps.setString(1, destinationFolder);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rsToObj(rs);
                } else {
                    return null;
                }
            }
        }
    }

    @Override
    public SourceAndDestinationFolder update(SourceAndDestinationFolder obj, String destinationFolder) throws SQLException {
        String req = "UPDATE sourceanddestinationfolder SET Destination = ? WHERE SourceFolder = ? AND Destination = ?;";
        try (PreparedStatement ps = conn.prepareStatement(req)) {
            ps.setString(1, destinationFolder);
            ps.setString(2, obj.getSourceFolder());
            ps.setString(3, obj.getDestinationFolder());
            ps.executeUpdate();
        }
        return findById(obj.getSourceFolder());
    }
}

