/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trifichierperso;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 *
 * @author steem
 */
public class Panneau extends JPanel implements ActionListener {
    //--Attribut-----------------------------------------------------------------------------------------------------------------------
    
    //--JButton------------------------------------------------------------------------------------------------------------------------
    private JButton btn_trier=new JButton("Trier");
    private JButton btn_parametre=new JButton("Paramétre");
    private JLabel jlb_triageEffectuer=new JLabel("Triage effectuer");
    
    //--Constructeur-------------------------------------------------------------------------------------------------------------------
    public Panneau() {
        intiPan();
    }

    private void intiPan() {
        //Parametrage------------------------------------------------------------------------------------------------------------------
        this.setLayout(null);
        //--JButton------------------------------------------------------------------------------------------------------------------------
        this.btn_trier.setBounds(200, 150, 100, 20);
        this.btn_trier.addActionListener(this);
        this.add(btn_trier);
        this.btn_parametre.setBounds(200, 180, 100, 20);
        this.btn_parametre.addActionListener(this);
        this.add(btn_parametre);
        this.jlb_triageEffectuer.setText("Le triage a éte effectuer avec succes");
        this.jlb_triageEffectuer.setBounds(150, 210, 300, 20);
        this.jlb_triageEffectuer.setVisible(false);
        this.add(jlb_triageEffectuer);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        switch (e.getActionCommand()) {
            //--Bouton trier----------------------------------------------------------------------------------------------------------------
            case "Trier":
                SourceAndDestinationFolder SDF=new SourceAndDestinationFolder();
                Connection conn = DAOFactory.getConnection(); 
                SourceAndDestinationFolderDao SDFD = new SourceAndDestinationFolderDao(conn);
            {
                try {
                    SourceAndDestinationFolder[] source=SDFD.findAll();
                    triagedetoutelesSource(source);
                } catch (SQLException ex) {
                    Logger.getLogger(Panneau.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                this.jlb_triageEffectuer.setVisible(true);
                break;

            //--Bouton Paramétre------------------------------------------------------------------------------------------------------------
            case "Paramétre":
                Fenetre fenetre = (Fenetre) SwingUtilities.getWindowAncestor(Panneau.this);
                fenetre.changepan( new PanneauParametre());
                break;

        }
    }
    private void triagedetoutelesSource(SourceAndDestinationFolder[] source){
    
    for(SourceAndDestinationFolder SDF :source ){
        
        TriageFichier Tf=new TriageFichier(SDF.getSourceFolder(), SDF.getDestinationFolder(),SDF.getFichier(),SDF.getDossier());
       
    }
    }

}
