/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trifichierperso;

import java.util.Objects;

/**
 *
 * @author steem
 */
public class ExtensionAndName {

    private String extension;
    private String FileName;

    //--Constructor------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public ExtensionAndName(String extension, String FileName) {
        this.extension = extension;
        this.FileName = FileName;
    }

    public ExtensionAndName() {
    }

//--Getter and Setter --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getFileName() {
        return FileName;
    }

    public void setFileName(String FileName) {
        this.FileName = FileName;
    }

    @Override
    public String toString() {
        return "ExtensionAndName{" + "extension=" + extension + ", FileName=" + FileName + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }
}
