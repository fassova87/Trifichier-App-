package com.mycompany.trifichierperso;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Launcheur {

    public static void main(String[] args) {
        // Créer la base de données et les tables si elles n'existent pas
        try (Connection con = DAOFactory.getConnection()) {
            if (con != null) {
                createTablesIfNotExists(con);
                SourceAndDestinationFolderDao dao = new SourceAndDestinationFolderDao(con);
                System.out.println("Tentative d'insertion des données...");
                System.out.println("Insertion réussie.");
            } else {
                System.out.println("Échec de la connexion à la base de données.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Launcheur.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erreur lors de l'insertion des données.");
        }

        // Démarrer l'application GUI
        Fenetre fenetre = new Fenetre();
        fenetre.setVisible(true);
    }

    private static void createTablesIfNotExists(Connection con) {
        String createTriinfoTableSQL = "CREATE TABLE IF NOT EXISTS triinfo ("
                + "extension TEXT PRIMARY KEY, "
                + "DossierDestination TEXT NOT NULL);";

        String createSourceAndDestinationFolderTableSQL = "CREATE TABLE IF NOT EXISTS sourceanddestinationfolder ("
                + "SourceFolder TEXT PRIMARY KEY, "
                + "Destination TEXT NOT NULL, "
                + "Fichier TEXT NOT NULL, "
                + "Dossier TEXT NOT NULL);";

        try (Statement stmt = con.createStatement()) {
            stmt.execute(createTriinfoTableSQL);
            stmt.execute(createSourceAndDestinationFolderTableSQL);
            System.out.println("Tables créées ou déjà existantes.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
