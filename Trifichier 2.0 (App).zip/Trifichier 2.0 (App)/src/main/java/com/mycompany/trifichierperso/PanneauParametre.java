/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trifichierperso;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author steem
 */
public class PanneauParametre extends JPanel implements ActionListener,ListSelectionListener{
  
// ATTRIBUTS-----------------------------------------------------------------------------------------------------------------------------------------------
   
    private JComboBox jcb_choixParametre = new JComboBox();
    private JComboBox jcb_triageFichier=new JComboBox();
    private JComboBox jcb_triageDossier=new JComboBox();
    private JButton btn_back = new JButton("< Back");
    private JButton btn_cree = new JButton("Crée");
    private JButton btn_modifier = new JButton("Modifier");
    private JButton btn_supprimer = new JButton("Supprimer");
    private JButton btn_rechercher = new JButton("Rechercher");
    private JTextField jtf_parametre1 = new JTextField();
    private JTextField jtf_parametre2 = new JTextField();
    private JLabel jlb_parametre1 = new JLabel("Extension :");
    private JLabel jlb_parametre2 = new JLabel("Dossier de Destination :");
    private JLabel jlb_parametre3=new JLabel("TriageFichier :");
    private JLabel jlb_parametre4=new JLabel("TriageDossier :");
    private JTable tbl_infoFolder = new JTable();
    private JScrollPane JSP_tableFolder = new JScrollPane(tbl_infoFolder);
    private String ChoixComboBox="Extension";
    private ExtensionAndName EAN= new ExtensionAndName();
    private SourceAndDestinationFolder SDF=new SourceAndDestinationFolder();
    private ExtensionAndNameDao EAND=new ExtensionAndNameDao();
    Connection conn = DAOFactory.getConnection(); 
    SourceAndDestinationFolderDao SDFD = new SourceAndDestinationFolderDao(conn);
    private String TriageDossier="Oui";
    private String TriageFichier="Oui";
    
// CONSTRUCTEUR-----------------------------------------------------------------------------------------------------------------------------------------------
    public PanneauParametre() {
        initPan();
    }  

    private void initPan() {
       this.setLayout(null);
//--Parametrage JButon----------------------------------------------------------------------------------------------------------------------------------
        this.btn_back.setBounds(29, 25, 74, 20);
        this.add(btn_back);
        this.btn_back.addActionListener(this);
        this.btn_cree.setBounds(50, 170, 110, 20);
        this.add(btn_cree);
        this.btn_cree.addActionListener(this);
        this.btn_modifier.setBounds(50, 200, 110, 20);
        this.add(btn_modifier);
        this.btn_modifier.addActionListener(this);
        this.btn_rechercher.setBounds(50, 230, 110, 20);
        this.add(btn_rechercher);
        this.btn_rechercher.addActionListener(this);
        this.btn_supprimer.setBounds(50, 260, 110, 20);
        this.add(btn_supprimer);
        this.btn_supprimer.addActionListener(this);

//--Parametrage JCombo Box----------------------------------------------------------------------------------------------------------------------------------
        this.jcb_choixParametre.setBounds(114, 25, 200, 20);
        this.add(jcb_choixParametre);
        this.jcb_choixParametre.addItem("Extension");
        this.jcb_choixParametre.setActionCommand("Choix");
        this.jcb_choixParametre.addItem("Source et Destination Folder");
        this.jcb_choixParametre.addActionListener(this);
        this.jcb_triageDossier.setBounds(145, 125, 70, 20);
        this.jcb_triageDossier.addItem("Oui");
        this.jcb_triageDossier.addItem("Non");
        this.jcb_triageDossier.setVisible(false);
        this.add(jcb_triageDossier);
        this.jcb_triageDossier.setActionCommand("Choix Dossier");
        this.jcb_triageDossier.addActionListener(this);
        this.jcb_triageFichier.setBounds(145, 150, 70, 20);
        this.jcb_triageFichier.addItem("Oui");
        this.jcb_triageFichier.addItem("Non");
        this.jcb_triageFichier.setActionCommand("Choix Fichier");
        this.jcb_triageFichier.addActionListener(this);
        this.jcb_triageFichier.setVisible(false);
        this.add(jcb_triageFichier);
        
        

        //--Parametrage Jlabel----------------------------------------------------------------------------------------------------------------------------------
        this.jlb_parametre1.setBounds(40, 75, 105, 20);
        this.add(jlb_parametre1);
        this.jlb_parametre2.setBounds(40, 100, 150, 20);
        this.add(jlb_parametre2);
        this.jlb_parametre3.setBounds(40, 125, 150, 20);
        this.jlb_parametre3.setVisible(false);
        this.add(jlb_parametre3);
        
        this.jlb_parametre4.setBounds(40, 150, 150, 20);
        this.jlb_parametre4.setVisible(false);
        this.add(jlb_parametre4);
        

        //--Parametrage Jtexfield----------------------------------------------------------------------------------------------------------------------------------
        this.jtf_parametre1.setBounds(180, 75, 100, 20);
        this.add(jtf_parametre1);
        this.jtf_parametre2.setBounds(180, 100, 100, 20);
        this.add(jtf_parametre2);
        
//        this.tbl_extension.getSelectionModel().addListSelectionListener(this);
        this.JSP_tableFolder.setViewportView(tbl_infoFolder);

//        this.tbl_infoFolder.setBounds(260, 140, 200, 200);
        this.add(tbl_infoFolder);
        this.tbl_infoFolder.getSelectionModel().addListSelectionListener(this);
        this.JSP_tableFolder.setViewportView(tbl_infoFolder);
        this.JSP_tableFolder.setBounds(200, 140, 260, 200);
        this.add(JSP_tableFolder);
        AfficherJtable();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        switch (e.getActionCommand()) {
//--BoutonParametre Back------------------------------------------------------------------------------------------------------------------------
            case "< Back":
//--Changement de panel de la fenetre--------------------------------------------------------------------------------------------------------
                Fenetre f = (Fenetre) SwingUtilities.getWindowAncestor(PanneauParametre.this);
                f.changepan(new Panneau());
                break;
//--BoutonParametre Crée------------------------------------------------------------------------------------------------------------------------                
            case "Crée":
//--Parametre bouton pour ExtensionAndName--------------------------------------------------------------------------------------------------------
                if (ChoixComboBox == "Extension") {
                    
                    if(this.jtf_parametre1.getText().isEmpty()||this.jtf_parametre2.getText().isEmpty()){
                        System.out.println("Veuillez remplir tout les casses"); 
                        JOptionPane.showMessageDialog(null, "Veuillez remplir tout les champs");
                    }else{
                    getInfo(EAN);
                       
                    try {

                        EAND.create(EAN);
                    } catch (SQLException ex) {
                        Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
                    }}
//--Parametre bouton pour SourceAndDestinationFolder--------------------------------------------------------------------------------------------------------                    
                } else if (ChoixComboBox == "Source et Destination Folder") {
                    JFrame frame=new JFrame();
                    Object[] options = {"Oui", "Non"};
                    JOptionPane Jop =new JOptionPane("");
                    int rep =Jop.showOptionDialog(frame,"Avez-vous choisi les paramètres de tri souhaités ?","Question", JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE, null,options,options[0] );
                    System.out.println(rep);
                    if(rep==0){
                    int resultDestination;
                    String selectedFileSource=this.jtf_parametre1.getText();
                    String selectedFileDestination=this.jtf_parametre2.getText();
                    if (this.jtf_parametre1.getText().isEmpty() || this.jtf_parametre2.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Veuillez sélectionner l'endroit à trier.");
                        JFileChooser fileChooserSource = new JFileChooser();
                        fileChooserSource.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                        int resultSource = fileChooserSource.showOpenDialog(null);
                        if (resultSource == JFileChooser.APPROVE_OPTION) {
                            selectedFileSource = fileChooserSource.getSelectedFile().toString();
                                JOptionPane.showMessageDialog(null, "Veuillez sélectionner où placer les fichiers triés.");
                            JFileChooser fileChooserDestination = new JFileChooser();
                            fileChooserDestination.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                            resultDestination = fileChooserDestination.showOpenDialog(null);
                            selectedFileDestination = fileChooserDestination.getSelectedFile().toString();       
                        }
                    }
                    System.out.println(selectedFileDestination);
                    System.out.println(selectedFileSource);
                    if(!selectedFileSource.isEmpty()||!selectedFileDestination.isEmpty()){
                                try {
                                    
                                    SDF.setSourceFolder(selectedFileSource);
                                    SDF.setDestinationFolder(selectedFileDestination);
                                    SDF.setDossier(TriageDossier);
                                    SDF.setFichier(TriageFichier);
                                    SDFD.create(SDF);
                                } catch (SQLException ex) {
                                    Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
                                }
                    }}
                        
                    
//---------------------------------------------------------------------------------------------------------------------------------------------------------                    
                } else {
                    System.out.println("ERROR");
                }
                AfficherJtable();
                break;
//--BoutonParametre Modifier------------------------------------------------------------------------------------------------------------------------
            case "Modifier":
//--Parametre bouton pour ExtensionAndName--------------------------------------------------------------------------------------------------------
                if (ChoixComboBox == "Extension") {
                                try {
                getInfo(EAN);
                EAN=EAND.update(EAN, this.jtf_parametre2.getText());
                setInfo(EAN);
            } catch (SQLException ex) {
                Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
            }
//--Parametre bouton pour SourceAndDestinationFolder--------------------------------------------------------------------------------------------------------                    
                } else if (ChoixComboBox == "Source et Destination Folder") {
                    int resultDestination;
                    String FileDestination;
                    
                    JOptionPane.showMessageDialog(null, "Veuillez sélectionner où placer les fichiers triés.");
                            JFileChooser fileChooserDestination = new JFileChooser();
                            fileChooserDestination.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                            resultDestination = fileChooserDestination.showOpenDialog(null);
                            FileDestination = fileChooserDestination.getSelectedFile().toString();  

                    getInfo(SDF);
                    SDF.setDestinationFolder(FileDestination);
                    System.out.println(SDF);
            try {
                
                System.out.println(SDF.toString());
                SDF=SDFD.update(SDF, SDF.getDestinationFolder(),SDF.getDossier(),SDF.getFichier());
            } catch (SQLException ex) {
                Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
            }
                    
                } else{
                    System.out.println("ERROR");
                }
                AfficherJtable();
                break;
//--BoutonParametre Supprimer------------------------------------------------------------------------------------------------------------------------
            case "Supprimer":
//--Parametre bouton pour ExtensionAndName--------------------------------------------------------------------------------------------------------
                if (ChoixComboBox == "Extension") {
                    getInfo(EAN);
            try {
                EAND.delete(EAN);
            } catch (SQLException ex) {
                Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
            }
//--Parametre bouton pour SourceAndDestinationFolder--------------------------------------------------------------------------------------------------------                    
                } else if (ChoixComboBox == "Source et Destination Folder") {
                    getInfo(SDF);
            try {
                SDFD.delete(SDF);
            } catch (SQLException ex) {
                Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
            }
                    
                } else{
                    System.out.println("ERROR");
                }
                AfficherJtable();
                break;
//--BoutonParametre Rechercher------------------------------------------------------------------------------------------------------------------------
            case "Rechercher":
//--Parametre bouton pour ExtensionAndName--------------------------------------------------------------------------------------------------------
                if (ChoixComboBox == "Extension") {
                    
                    try {
                        getInfo(EAN);
                        EAN=EAND.findById(EAN.getExtension());
                        setInfo(EAN);
                    } catch (SQLException ex) {
                        Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
                    }
//--Parametre bouton pour SourceAndDestinationFolder--------------------------------------------------------------------------------------------------------
                } else if (ChoixComboBox == "Source et Destination Folder") {
                    try {
                        getInfo(SDF);
                        SDF=SDFD.findById(SDF.getSourceFolder());
                        setInfo(SDF);
                    } catch (SQLException ex) {
                        Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
                    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
                } else {
                    System.out.println("ERROR");
                }
                
                break;
//--BoutonParametre ComboBox------------------------------------------------------------------------------------------------------------------------
            case "Choix":
                
                if (this.jcb_choixParametre.getSelectedItem() == "Extension") {
                    this.jtf_parametre1.setText("");
                    this.jtf_parametre2.setText("");
                    ChoixComboBox="Extension";
                    this.jlb_parametre1.setText("Extension :");
                    this.jlb_parametre2.setText("Dossier de Destination :");
                    this.jtf_parametre1.setBounds(180, 75, 100, 20);
                    this.jtf_parametre2.setBounds(180, 100, 100, 20);
                    this.JSP_tableFolder.setBounds(200, 140, 260, 200);
                    this.jlb_parametre3.setVisible(false);
                    this.jlb_parametre4.setVisible(false);
                    this.jcb_triageDossier.setVisible(false);
                    this.jcb_triageFichier.setVisible(false);
                    this.btn_cree.setBounds(50, 170, 110, 20);
                    this.btn_modifier.setBounds(50, 200, 110, 20);
                    this.btn_rechercher.setBounds(50, 230, 110, 20);
                    this.btn_supprimer.setBounds(50, 260, 110, 20);
                    
                    
                } else if (this.jcb_choixParametre.getSelectedItem() == "Source et Destination Folder") {
                    this.jtf_parametre1.setText("");
                    this.jtf_parametre2.setText("");
                    this.jlb_parametre3.setVisible(true);
                    this.jlb_parametre4.setVisible(true);
                    this.jcb_triageDossier.setVisible(true);
                    this.jcb_triageFichier.setVisible(true);
                    this.jlb_parametre1.setText("Source :");
                    this.jlb_parametre2.setText("Destination :");
                    ChoixComboBox="Source et Destination Folder";
                    this.jtf_parametre1.setBounds(145, 75, 190, 20);
                    this.jtf_parametre2.setBounds(145, 100, 190, 20);
                    this.btn_cree.setBounds(225, 125,110, 20);
                    this.btn_modifier.setBounds(225, 150, 110, 20);
                    this.btn_rechercher.setBounds(340, 125, 110, 20);
                    this.btn_supprimer.setBounds(340, 150, 110, 20);
                    
                    this.JSP_tableFolder.setBounds(50, 180, 400, 170);
                } else {
                    ChoixComboBox="ERROR";
                    System.out.println("ERROR");   
                }
                AfficherJtable();
                break;
//--Combo box de triage dossier------------------------------------------------------------------------------------------------------------------
            case"Choix Dossier":
                if(jcb_triageDossier.getSelectedItem()=="Oui"){
                SDF.setDossier("Oui");
                TriageDossier="Oui";
                }else if(jcb_triageDossier.getSelectedItem()=="Non"){
                SDF.setDossier("Non");
                TriageDossier="Non";
                }else {
                    System.out.println("erreur");
                }
            break;
//--Combo box de triage Fichier------------------------------------------------------------------------------------------------------------------
            case"Choix Fichier":

                if(jcb_triageFichier.getSelectedItem()=="Oui"){
                SDF.setFichier("Oui");
                TriageFichier="Oui";
                }else if(jcb_triageFichier.getSelectedItem()=="Non"){
                SDF.setFichier("Non");
                TriageFichier="Non";
                }else {
                    System.out.println("erreur");
                }
            break;

            default:
                throw new AssertionError();
        }
    }
    private void setInfo(ExtensionAndName EAN) {
        this.jtf_parametre1.setText(EAN.getExtension());
        this.jtf_parametre2.setText(EAN.getFileName());
    }

    private void getInfo(ExtensionAndName EAN) {
        EAN.setExtension(this.jtf_parametre1.getText());
        EAN.setFileName(this.jtf_parametre2.getText());
    }
    private void setInfo(SourceAndDestinationFolder SDF) {
        this.jtf_parametre1.setText(SDF.getSourceFolder());
        this.jtf_parametre2.setText(SDF.getDestinationFolder());
    }

    private void getInfo(SourceAndDestinationFolder SDF) {
        SDF.setSourceFolder(this.jtf_parametre1.getText());
        SDF.setDestinationFolder(this.jtf_parametre2.getText());
        System.out.println(TriageDossier);
        SDF.setFichier(TriageFichier);
        System.out.println(TriageDossier);
        SDF.setDossier(TriageDossier);
        
    }

      private void AfficherJtable() {
        ResultSet rs = null;
        DefaultTableModel dtm = new DefaultTableModel();
         ResultSetMetaData rsmd=null;
        if (ChoixComboBox == "Extension") {
            try {
                rs=EAND.findallRs();
            } catch (SQLException ex) {
                Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (ChoixComboBox == "Source et Destination Folder") {
            try {
                rs=SDFD.findallRs();
            } catch (SQLException ex) {
                Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            System.out.println("ERROR");
        } 
         try {
             rsmd = rs.getMetaData();
             for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                 dtm.addColumn(rsmd.getColumnName(i));
             }
            while (rs.next()) {
                if (ChoixComboBox == "Extension") {
                    String[] ligne = {rs.getString(1), rs.getString(2)};
                    dtm.addRow(ligne);
                } else if (ChoixComboBox == "Source et Destination Folder") {
                    String[] ligne = {rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)};
                    dtm.addRow(ligne);
                } else {
                    System.out.println("Error");
                }
            }
            this.tbl_infoFolder.setModel(dtm);
        } catch (SQLException ex) {
            Logger.getLogger(PanneauParametre.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
            if (tbl_infoFolder.getSelectedRow() != -1) {
                if (ChoixComboBox == "Extension") {
                    this.jtf_parametre1.setText(this.tbl_infoFolder.getValueAt(tbl_infoFolder.getSelectedRow(), 0).toString());
                    this.jtf_parametre2.setText(this.tbl_infoFolder.getValueAt(tbl_infoFolder.getSelectedRow(), 1).toString());
                    
                } else if (ChoixComboBox == "Source et Destination Folder") {
                    this.jtf_parametre1.setText(this.tbl_infoFolder.getValueAt(tbl_infoFolder.getSelectedRow(), 0).toString());
                    this.jtf_parametre2.setText(this.tbl_infoFolder.getValueAt(tbl_infoFolder.getSelectedRow(), 1).toString());
                    this.jcb_triageDossier.setSelectedItem(this.tbl_infoFolder.getValueAt(tbl_infoFolder.getSelectedRow(),2).toString());
                    this.jcb_triageFichier.setSelectedItem(this.tbl_infoFolder.getValueAt(tbl_infoFolder.getSelectedRow(), 3).toString());
                }
            }
        }
    }
}
