package com.mycompany.trifichierperso;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAOFactory {

    private static final String DRIVER = "org.sqlite.JDBC";
    private static final String DATABASE_URL = "jdbc:sqlite:./database.db"; // Chemin relatif à la base de données

    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(DATABASE_URL);
            //System.out.println("Connexion réussie à : " + DATABASE_URL);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DAOFactory.class.getName()).log(Level.SEVERE, "Une erreur est survenue lors de la connexion à la base de données.", ex);
        }
        return conn;
    }
}


