/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trifichierperso;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author steem
 */
public class TriageFichier {

    private String SourceFolder;
    private String DestinationFolder;
    private ExtensionAndNameDao EAND = new ExtensionAndNameDao();
    private ExtensionAndName EAN = new ExtensionAndName();
    private String TriageFichier;
    private String TriageDossier;

    public TriageFichier(String SourceFolder, String DestinationFolder, String TriageFichier, String TriageDossier) {
        this.SourceFolder = SourceFolder;
        this.DestinationFolder = DestinationFolder;
        this.TriageDossier = TriageDossier;
        this.TriageFichier = TriageFichier;
        TrierFichier();
    }

    public void TrierFichier() {
        String extension;
        String filename;
        File folder = new File(SourceFolder);
        File[] listFile = folder.listFiles();
        //recupéretoutles fichier existant dans la source
        if (listFile != null) {
            for (File file : listFile) {
                if (file.isFile() && TriageFichier.equals("Oui")) {
//--Gestion des Fichier--------------------------------------------------------------------------------------------------------------------------------------------

                    boolean extensionExist;
                    filename = file.getName();
                    extension = getExtension(file.getName());
                    ;

                    try {
                        EAN = EAND.findById(extension);

                    } catch (SQLException ex) {
                        Logger.getLogger(TriageFichier.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (EAN.getExtension() == null) {
//--Sans extension non prit en charge------------------------------------------------------------------------------------------------------------------------------
//--Creation des dossier si non existant------------------------------------------------------------------------------------------------------------------------             
                        String FolderDossierPath = DestinationFolder + "\\" + "Autre" + "\\" + extension;

                        Path pathDossierNE = Paths.get(FolderDossierPath);
                        if (Files.exists(pathDossierNE)) {
                            System.out.println("Le dossier a déja été crée");
                        } else {
                            try {
                                Files.createDirectories(pathDossierNE);
                                System.out.println("Création d'un dossier");
                            } catch (IOException ex) {
                                Logger.getLogger(TriageFichier.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } else {
//avec extension pris en charge------------------------------------------------------------------------------------------------------------------------------
//--Creation des dossier si non existant------------------------------------------------------------------------------------------------------------------------             
                        String FolderDossierPath = DestinationFolder + "\\" + EAN.getFileName();

                        Path pathDossierE = Paths.get(FolderDossierPath);

                        if (Files.exists(pathDossierE)) {
                            System.out.println("Le dossier a déja été crée");
                        } else {
                            try {
                                Files.createDirectories(pathDossierE);
                                System.out.println("Création d'un dossier");

                            } catch (IOException ex) {
                                Logger.getLogger(TriageFichier.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                    }
//--Deplacement des fichier avec extension pris en charge---------------------------------------------------------------------------------------------
                    if (EAN.getExtension() != null) {
                        String SourceFichierPath = SourceFolder + "\\" + filename;
                        String DestinationFichierPath = DestinationFolder + "\\" + EAN.getFileName() + "\\" + filename;
                        Path pathSourceFichierE = Paths.get(SourceFichierPath);
                        Path pathDestinationFichierE = Paths.get(DestinationFichierPath);
                        try {
                            Files.move(pathSourceFichierE, pathDestinationFichierE);
                            System.out.println("Fichier deplace");

                        } catch (IOException ex) {
                            Logger.getLogger(TriageFichier.class.getName()).log(Level.SEVERE, null, ex);
                        }
//Deplacement des fichier avec extension non pris en charge 
                    } else {
                        String FolderDossierPath = DestinationFolder + "\\" + "Autre" + "\\" + extension;
                        String SourceFichierPath = SourceFolder + "\\" + filename;
                        String DestinationFichierPath = DestinationFolder + "\\" + "Autre" + "\\" + extension + "\\" + filename;
                        Path pathSourceFichierNE = Paths.get(SourceFichierPath);
                        Path pathDestinationFichierE = Paths.get(DestinationFichierPath);
                        try {
                            Files.move(pathSourceFichierNE, pathDestinationFichierE, StandardCopyOption.REPLACE_EXISTING);
                        } catch (IOException ex) {
                            Logger.getLogger(TriageFichier.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                if (!file.isFile() && TriageDossier.equals("Oui")) {
//--Gestion des Dossier------------------------------------------------------------------------------------------------------------------------
                    String Dossier;
                    String Resulta;
                    Boolean DossierC = false;
                    int dotIndex = file.toString().lastIndexOf("\\");
                    if (dotIndex > -1) {
                        Dossier = file.toString().substring(dotIndex + 1);
                    } else {
                        System.out.println("Erreur");
                        Dossier = "";
                    }

                    try {
                        ExtensionAndName[] EANT = EAND.findAll();
                        if (Dossier.equals("Autre") || Dossier.equals("Dossier")) {
                            DossierC = true;
                        }
                        for (ExtensionAndName EAN : EANT) {
                            if (DossierC == false) {
                                Resulta = EAN.getFileName();
                                if (Dossier.equals(Resulta)) {
                                    DossierC = true;
                                }
                            }
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(TriageFichier.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (DossierC == false) {
                        String SourceDossierPath = SourceFolder + "\\" + Dossier;
                        String DestinationDossierPath = DestinationFolder + "\\" + "Dossier" + "\\" + Dossier;
                        String DossierD = DestinationFolder + "\\" + "Dossier";
                        Path pathSourceDossierNE = Paths.get(SourceDossierPath);
                        Path pathDestinationDossierNE = Paths.get(DestinationDossierPath);
                        Path PathDossierD = Paths.get(DossierD);
                        if (!Files.exists(PathDossierD)) {

                            try {
                                Files.createDirectories(PathDossierD);
                            } catch (IOException ex) {
                                Logger.getLogger(TriageFichier.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                        try {
                            Files.move(pathSourceDossierNE, pathDestinationDossierNE, StandardCopyOption.REPLACE_EXISTING);
                        } catch (IOException ex) {
                            Logger.getLogger(TriageFichier.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    }
                }
            }
        } else {
            System.out.println("Le Dossier est vide ou n'existe pas");
        }

    }

    private String getExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex == -1) ? "" : fileName.substring(dotIndex);
    }

}
